// Dont have to compute shadow ray -> TA
package ray.renderer;

import java.util.ArrayList;

import ray.light.PointLight;
import ray.misc.Color;
import ray.material.Material;
import ray.misc.Ray;
import ray.misc.Scene;
import ray.sampling.SampleGenerator;
import ray.misc.IntersectionRecord;
import ray.math.Point2;
import ray.math.Vector3;
import ray.math.Geometry;
import ray.misc.LuminaireSamplingRecord;
import ray.brdf.BRDF;

public class PhongShader implements Renderer {
    
    private double phongCoeff = 2.5;
    
    public PhongShader() { }
    
    public void setAlpha(double a) {
        phongCoeff = a;
    }
    
    @Override
    public void rayRadiance(Scene scene, Ray ray, SampleGenerator sampler,
            int sampleIndex, Color outColor) {
        // W4160 TODO (A)
        // Here you need to implement the basic phong reflection model to calculate
        // the color value (radiance) along the given ray. The output color value 
        // is stored in outColor. 
        // 
        // For such a simple rendering algorithm, you might not need Monte Carlo integration
        // In this case, you can ignore the input variable, sampler and sampleIndex.

        Color tempColor = new Color(0,0,0);
        outColor.r = outColor.g = outColor.b = 0; // set outcolor to 0 and then we increment it.

        // find if the ray intersect with any surface
        IntersectionRecord iRec = new IntersectionRecord();

        if (scene.getFirstIntersection(iRec, ray)) {

            IntersectionRecord tempRec = new IntersectionRecord();
            tempRec.set(iRec);

            // BRDF for surface in question 
            BRDF temp = iRec.surface.getMaterial().getBRDF(iRec);
            
             // Ambient Light
            // Get color, assuming lambertian (needs change for Microfacets?)
            Vector3 normal = iRec.frame.w;
            Double direction_dot_normal_2 = -2 * (ray.direction.x * normal.x + ray.direction.y * normal.y + ray.direction.z * normal.z);
            Vector3 direction = new Vector3(direction_dot_normal_2 * normal.x + ray.direction.x, direction_dot_normal_2 * normal.y + ray.direction.y, direction_dot_normal_2 * normal.z + ray.direction.z);

            temp.evaluate(iRec.frame, ray.direction, new Vector3(1,0,0), tempColor);

            //System.out.printf("Color: %f %f %f", tempColor.r, tempColor.b, tempColor.g);

            outColor.r += tempColor.r * .05;
            outColor.g += tempColor.g * .05;
            outColor.b += tempColor.b * .05;

            // Diffuse Light
            // Iterate through point lights and 
            ArrayList<PointLight> pointLights = scene.getPointLights();
            for (PointLight pl: pointLights)
            {

                iRec.set(tempRec);
                // PointLight pl = pointLights.get(0);

                Ray shadowRay = new Ray(iRec.frame.o, new Vector3(pl.location.x - iRec.frame.o.x, pl.location.y - iRec.frame.o.y, pl.location.z - iRec.frame.o.z ));
                shadowRay.makeOffsetRay();

                // check if subject is hit by light
                // if yes then include diffuse and specular lighting
                // if (!scene.getFirstIntersection(iRec, shadowRay)) {
                if(true){

                    double diffuseDotProd = shadowRay.direction.x * normal.x + shadowRay.direction.y * normal.y + shadowRay.direction.z * normal.z;

                    // Diffuse
                    if (diffuseDotProd > 0)
                    {
                        outColor.r += (tempColor.r * diffuseDotProd) * pl.diffuse.r;
                        outColor.g += (tempColor.g * diffuseDotProd) * pl.diffuse.g;
                        outColor.b += (tempColor.b * diffuseDotProd) * pl.diffuse.b;
                    }

                    Vector3 r = new Vector3();
                    r.x = -shadowRay.direction.x + 2 * normal.x * diffuseDotProd;
                    r.y = -shadowRay.direction.y + 2 * normal.y * diffuseDotProd;
                    r.z = -shadowRay.direction.z + 2 * normal.z * diffuseDotProd;

                    // Assuming viewing direction (0,0,1)
                    double specDotProd = -ray.direction.x * r.x - ray.direction.y * r.y - ray.direction.z * r.z;
                    // QUESTION: where to get shininess?

                    // Speular
                    if (specDotProd > 0)
                    {
                        outColor.r += (tempColor.r * Math.pow(specDotProd,phongCoeff)) * pl.specular.r;
                        outColor.g += (tempColor.g * Math.pow(specDotProd,phongCoeff)) * pl.specular.g;
                        outColor.b += (tempColor.b * Math.pow(specDotProd,phongCoeff)) * pl.specular.b;
                    }

                } 
            }

            return;
        }

        scene.getBackground().evaluate(ray.direction, outColor);
    }
}
