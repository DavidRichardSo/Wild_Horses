package ray.renderer;

import ray.brdf.BRDF;
import ray.material.Material;
import ray.math.Geometry;
import ray.math.Point2;
import ray.math.Vector3;
import ray.misc.Color;
import ray.misc.IntersectionRecord;
import ray.misc.Ray;
import ray.misc.Scene;
import ray.sampling.SampleGenerator;

public abstract class PathTracer extends DirectOnlyRenderer {

    protected int depthLimit = 5;
    protected int backgroundIllumination = 1;

    public void setDepthLimit(int depthLimit) { this.depthLimit = depthLimit; }
    public void setBackgroundIllumination(int backgroundIllumination) { this.backgroundIllumination = backgroundIllumination; }

    @Override
    public void rayRadiance(Scene scene, Ray ray, SampleGenerator sampler, int sampleIndex, Color outColor) {
    
        rayRadianceRecursive(scene, ray, sampler, sampleIndex, 0, outColor);
    }

    protected abstract void rayRadianceRecursive(Scene scene, Ray ray, SampleGenerator sampler, int sampleIndex, int level, Color outColor);

    public void gatherIllumination(Scene scene, Vector3 outDir, 
            IntersectionRecord iRec, SampleGenerator sampler, 
            int sampleIndex, int level, Color outColor) {
    	// W4160 TODO (B)
    	//
        // This method computes a Monte Carlo estimate of reflected radiance due to direct and/or indirect 
        // illumination.  It generates samples uniformly wrt. the projected solid angle measure:
        //
        //    f = brdf * radiance
        //    p = 1 / pi
        //    g = f / p = brdf * radiance * pi
    	// You need: 
    	//   1. Generate a random incident direction according to proj solid angle
    	//      pdf is constant 1/pi
    	//   2. Recursively find incident radiance from that direction
    	//   3. Estimate the reflected radiance: brdf * radiance / pdf = pi * brdf * radiance

            // Limit Recursion Depth
            if (level < depthLimit){

                if (iRec.surface.getMaterial().isEmitter())
                {
                    outColor.set(1,1,1);
                    return;
                }

                Color radiance = new Color();
                Vector3 shadow_dir = new Vector3(outDir.x, outDir.y, outDir.z);

                if (level == 0)
                {

                    if (iRec.surface.getMaterial().isMirror())
                    {

                        Vector3 mirror_normal = iRec.frame.w;
                        Double mirror_direction_dot_normal_2 = -2 * (outDir.x * mirror_normal.x + outDir.y * mirror_normal.y + outDir.z * mirror_normal.z);
                        shadow_dir = new Vector3(mirror_direction_dot_normal_2 * mirror_normal.x + outDir.x, mirror_direction_dot_normal_2 * mirror_normal.y + outDir.y, mirror_direction_dot_normal_2 * mirror_normal.z + outDir.z);
                        shadow_dir.normalize();
                        // shadow_dir = iRec.frame.w;

                        // System.out.printf("Normal: %f %f %f\n", mirror_normal.x, mirror_normal.y ,mirror_normal.z);

                        // System.out.printf("Before: %f %f %f\n", shadow_dir.x, shadow_dir.y ,shadow_dir.z);

                        // Point2 seed = new Point2();
                        // sampler.sample(1, sampleIndex, seed);     // this random variable is for incident direction
                        // Geometry.squareToPSAHemisphere(seed, shadow_dir);

                        // System.out.printf("Middle: %f %f %f\n", shadow_dir.x, shadow_dir.y ,shadow_dir.z);

                        // iRec.frame.frameToCanonical(shadow_dir);

                        // System.out.printf("After: %f %f %f\n", shadow_dir.x, shadow_dir.y ,shadow_dir.z);
                    }
                    else
                    {
                        Point2 seed = new Point2();
                        sampler.sample(1, sampleIndex, seed);     // this random variable is for incident direction
                        Geometry.squareToPSAHemisphere(seed, shadow_dir);
                        iRec.frame.frameToCanonical(shadow_dir);
                    }
                        // Point2 seed = new Point2();
                        // sampler.sample(1, sampleIndex, seed);     // this random variable is for incident direction
                        // Geometry.squareToPSAHemisphere(seed, shadow_dir);
                        // iRec.frame.frameToCanonical(shadow_dir);

                }

                else
                {
                    Vector3 mirror_normal = iRec.frame.w;
                    Double mirror_direction_dot_normal_2 = -2 * (outDir.x * mirror_normal.x + outDir.y * mirror_normal.y + outDir.z * mirror_normal.z);
                    shadow_dir = new Vector3(mirror_direction_dot_normal_2 * mirror_normal.x + outDir.x, mirror_direction_dot_normal_2 * mirror_normal.y + outDir.y, mirror_direction_dot_normal_2 * mirror_normal.z + outDir.z);
                    shadow_dir.normalize();
                }
                
                Ray shadowRay = new Ray(iRec.frame.o, shadow_dir);
                shadowRay.makeOffsetRay();

                IntersectionRecord second_Rec = new IntersectionRecord(); 

                if (scene.getFirstIntersection(second_Rec, shadowRay)) 
                {

                    if (iRec.surface.getMaterial().isMirror())
                    {
                        // Color tempColor = new Color(0,0,0);
                        // BRDF temp = second_Rec.surface.getMaterial().getBRDF(second_Rec);
                        // temp.evaluate(second_Rec.frame, new Vector3 (0, 0, 1), new Vector3 (0,0,1), tempColor);
                        // outColor.set(tempColor.r * Math.PI, tempColor.g * Math.PI, tempColor.b * Math.PI);

                        gatherIllumination(scene, shadow_dir, second_Rec, sampler, sampleIndex, level, outColor);
                        // if (level == 0) 
                        // {
                        //     System.out.printf("Color: %f %f %f\n", tempColor.r, tempColor.g, tempColor.b);
                        // }
                    }

                    // Check for emitter
                    else if (second_Rec.surface.getMaterial().isEmitter())
                    {
                        Vector3 emitDir = new Vector3(-shadowRay.direction.x, -shadowRay.direction.y, -shadowRay.direction.z);
                        emittedRadiance(second_Rec, emitDir, radiance);
                        // BRDF for surface in question 
                        BRDF temp = iRec.surface.getMaterial().getBRDF(iRec);
                        // Get color, assuming lambertian (needs change for Microfacets?)
                        Color tempColor = new Color(0,0,0);
                        temp.evaluate(iRec.frame, new Vector3 (0, 0, 1), new Vector3 (0,0,1), tempColor);
                        outColor.set(radiance.r * tempColor.r * Math.PI, radiance.g * tempColor.g * Math.PI, radiance.b * tempColor.b * Math.PI);
                    }

                    // need to include mirror

                    // Else, not an emitter
                    else
                    {
                        // Vector3 direction = new Vector3(direction_dot_normal_2 * normal.x + shadowRay.direction.x, direction_dot_normal_2 * normal.y + shadowRay.direction.y, direction_dot_normal_2 * normal.z + shadowRay.direction.z);
                        Color tempColor = new Color(0,0,0);
                        BRDF temp = iRec.surface.getMaterial().getBRDF(iRec);
                        temp.evaluate(iRec.frame, new Vector3 (0, 0, 1), new Vector3 (0,0,1), tempColor);
                        gatherIllumination(scene, shadow_dir, second_Rec, sampler, sampleIndex, level + 1, radiance);
                        // if (level == 0)
                        // {
                        //     outColor.set(radiance.r * tempColor.r * Math.PI, radiance.g * tempColor.g * Math.PI, radiance.b * tempColor.b * Math.PI);
                        // }
                        // else
                        // {
                        //     outColor.set(radiance.r * tempColor.r , radiance.g * tempColor.g, radiance.b * tempColor.b);
                        // }
                        outColor.set(radiance.r * tempColor.r * Math.PI, radiance.g * tempColor.g * Math.PI, radiance.b * tempColor.b * Math.PI);
                    }

                }
                else
                {
                    outColor.set(0,0,0);
                }

            }
            // else if (level < depthLimit)
            // {
            // }
            else
            {
                outColor.set(0,0,0);
            }
    }
}
