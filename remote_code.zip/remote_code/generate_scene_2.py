import sys

try:
	f1 = open(sys.argv[1],'r')
	f2 = open(sys.argv[2],'w')
	frame_number = int(sys.argv[3]) 
except:
	"Usage: <backup file> <file to write> <frame number>"

count  = 1 # file lines are 1 indexed
speed = .4
horse_number = frame_number % 24
for line in f1:

	if count == 66:
		f2.write("\t\t<data>horse_")
		f2.write(str(horse_number))
		f2.write(".msh</data>\n")

	elif count == 76:
		f2.write("\t\t<data>horse_")
		f2.write(str((horse_number + 10) %24))
		f2.write(".msh</data>\n")

	elif count == 86:
		f2.write("\t\t<data>horse_")
		f2.write(str((horse_number + 15) %24))
		f2.write(".msh</data>\n")

	elif count == 96:
		f2.write("\t\t<data>horse_")
		f2.write(str((horse_number + 5) %24))
		f2.write(".msh</data>\n")

	# elif count == 74:
	# 	f2.write("<v0> " + str(-1 + speed * frame_number) + " 1 -7</v0>\n")

	# elif count == 75:
	# 	f2.write("<v1> " + str(-1 + speed * frame_number) + " -.5 -7</v1>\n")

	# elif count == 82:
	# 	f2.write("<v2> " + str(-1 + speed * frame_number) + " 1 -7</v2>\n")

	# elif count == 88:
	# 	f2.write("<v0> " + str(-1 + speed * frame_number) + " -.5 7</v0>\n")

	# elif count == 89:
	# 	f2.write("<v1> " + str(-1 + speed * frame_number) + " 1 7</v1>\n")

	# elif count == 96:
	# 	f2.write("<v2> " + str(-1 + speed * frame_number) + " 1 7</v2>\n")

	else:
		f2.write(line)
	count += 1

f1.close()
f2.close()
