package ray.surface;

import ray.accel.AxisAlignedBoundingBox;
import ray.material.Material;
import ray.math.Geometry;
import ray.math.Point2;
import ray.math.Point3;
import ray.math.Vector3;
import ray.misc.IntersectionRecord;
import ray.misc.LuminaireSamplingRecord;
import ray.misc.Ray;


/**
 * Represents a sphere as a center and a radius.
 *
 * @author ags
 */
public class Sphere extends Surface {
    
    /** Material for this sphere. */
    protected Material material = Material.DEFAULT_MATERIAL;
    
    /** The center of the sphere. */
    protected final Point3 center = new Point3();
    
    /** The radius of the sphere. */
    protected double radius = 1.0;
    
    /**
     * Default constructor, creates a sphere at the origin with radius 1.0
     */
    public Sphere() {        
    }
    
    /**
     * The explicit constructor. This is the only constructor with any real code
     * in it. Values should be set here, and any variables that need to be
     * calculated should be done here.
     *
     * @param newCenter The center of the new sphere.
     * @param newRadius The radius of the new sphere.
     * @param newMaterial The material of the new sphere.
     */
    public Sphere(Vector3 newCenter, double newRadius, Material newMaterial) {        
        material = newMaterial;
        center.set(newCenter);
        radius = newRadius;
        updateArea();
    }
    
    public void updateArea() {
    	area = 4 * Math.PI * radius*radius;
    	oneOverArea = 1. / area;
    }
    
    /**
     * @see ray1.surface.Surface#getMaterial()
     */
    public Material getMaterial() {
        return material;
    }
    
    /**
     * @see ray1.surface.Surface#setMaterial(ray1.material.Material)
     */
    public void setMaterial(Material material) {
        this.material = material;
    }
    
    /**
     * Returns the center of the sphere in the input Point3
     * @param outPoint output space
     */
    public void getCenter(Point3 outPoint) {        
        outPoint.set(center);        
    }
    
    /**
     * @param center The center to set.
     */
    public void setCenter(Point3 center) {        
        this.center.set(center);        
    }
    
    /**
     * @return Returns the radius.
     */
    public double getRadius() {
        return radius;
    }
    
    /**
     * @param radius The radius to set.
     */
    public void setRadius(double radius) {
        this.radius = radius;
        updateArea();
    }
    
    public boolean chooseSamplePoint(Point3 p, Point2 seed, LuminaireSamplingRecord lRec) {
        Geometry.squareToSphere(seed, lRec.frame.w);
        lRec.frame.o.set(center);
        lRec.frame.o.scaleAdd(radius, lRec.frame.w);
        lRec.frame.initFromW();
        lRec.pdf = oneOverArea;
        lRec.emitDir.sub(p, lRec.frame.o);
        return true;
    }
        
    /**
     * @see ray1.surface.Surface#intersect(ray1.misc.IntersectionRecord,
     *      ray1.misc.Ray)
     */
    public boolean intersect(IntersectionRecord outRecord, Ray ray) {
        // W4160 TODO (A)
    	// In this function, you need to test if the given ray intersect with a sphere.
    	// You should look at the intersect method in other classes such as ray.surface.Triangle.java
    	// to see what fields of IntersectionRecord should be set correctly.
    	// The following fields should be set in this function
    	//     IntersectionRecord.t
    	//     IntersectionRecord.frame
    	//     IntersectionRecord.surface
    	//
    	// Note: Although a ray is conceptually a infinite line, in practice, it often has a length,
    	//       and certain rendering algorithm relies on the length. Therefore, here a ray is a 
    	//       segment rather than a infinite line. You need to test if the segment is intersect
    	//       with the sphere. Look at ray.misc.Ray.java to see the information provided by a ray.

        Vector3 b = new Vector3 (center.x - ray.origin.x, center.y - ray.origin.y, center.z - ray.origin.z);
        double projMag = b.x * ray.direction.x + b.y * ray.direction.y + b.z * ray.direction.z;
        Vector3 bProj = new Vector3(ray.origin.x + projMag * ray.direction.x, ray.origin.y + projMag * ray.direction.y, ray.origin.z + projMag * ray.direction.z);
        Vector3 center_bProj = new Vector3(bProj.x - center.x, bProj.y - center.y, bProj.z - center.z); 
        double distanceToRay = Math.sqrt(center_bProj.x * center_bProj.x + center_bProj.y * center_bProj.y + center_bProj.z * center_bProj.z);

        // No intersection 
        if (distanceToRay > radius)
        {
            return false;
        }
       
        // Tangent intercept
        if (distanceToRay == radius  && projMag >= ray.start && projMag <= ray.end)
        {
            outRecord.t = projMag;
            outRecord.surface = this;
            double center_bProj_norm = Math.sqrt(center_bProj.x * center_bProj.x + center_bProj.y * center_bProj.y + center_bProj.z * center_bProj.z);
            outRecord.frame.w.set(center_bProj.x / center_bProj_norm, center_bProj.y / center_bProj_norm, center_bProj.z / center_bProj_norm);
            outRecord.frame.initFromW();
            return true;
        }

        double distanceToIntercept = Math.sqrt(radius * radius - distanceToRay * distanceToRay);

        // Non-tangent intercept
        if (projMag - distanceToIntercept >= ray.start && projMag - distanceToIntercept <= ray.end)
        {
            outRecord.t = projMag - distanceToIntercept;
            // System.out.printf("Start: %f\n", ray.start);
            // System.out.printf("End: %f\n", ray.end);
            // System.out.printf("t: %f\n", outRecord.t);
            outRecord.surface = this;
            double dToI = projMag - distanceToIntercept;
            Vector3 centerToIntercept = new Vector3(ray.origin.x + dToI * ray.direction.x - center.x, ray.origin.y + dToI * ray.direction.y - center.y, ray.origin.z + dToI * ray.direction.z - center.z);
            outRecord.frame.o.set(bProj.x,bProj.y,bProj.z);
            outRecord.frame.w.set(centerToIntercept.x/(radius), centerToIntercept.y/(radius), centerToIntercept.z/(radius));
            // System.out.printf("Norm: %f\n", Math.sqrt(centerToIntercept.x/(radius) * centerToIntercept.x/(radius) + centerToIntercept.y/(radius) * centerToIntercept.y/(radius) + centerToIntercept.z/(radius) * centerToIntercept.z/(radius)));
            outRecord.frame.initFromW();
            // System.out.printf("Radius Battle: %f vs %f", Math.sqrt(centerToIntercept.x * centerToIntercept.x + centerToIntercept.y * centerToIntercept.y + centerToIntercept.z * centerToIntercept.z), radius);
            return true;
        }
    	
        return false;
    }
    

    /**
     * @see Object#toString()
     */
    public String toString() {
        return "sphere " + center + " " + radius + " " + material + " end";
    }
    
    /**
     * @see ray1.surface.Surface#addToBoundingBox(ray1.surface.accel.AxisAlignedBoundingBox)
     */
    public void addToBoundingBox(AxisAlignedBoundingBox inBox) {
        inBox.add(center.x - radius, center.y - radius, center.z - radius);
        inBox.add(center.x + radius, center.y + radius, center.z + radius);        
    }
    
}
